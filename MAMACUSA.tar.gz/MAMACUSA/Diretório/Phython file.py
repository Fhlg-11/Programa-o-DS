nome = input("Qual o seu nome?")
idade = input("Sua idade?")
altura = input("Qual a sua altura")

print("seu nome é " + nome + ",","Você tem " + idade + " anos e a","Sua altura é de " + altura(1:2) + " Metros" )