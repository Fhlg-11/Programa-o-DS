class Personagem:
    def __init__(self, nome, vida, destreza, forca, intel, const, nivel=1):
        self.nome = nome
        self.vida =vida
        self.destreza = destreza
        self.forca = forca
        self.intel = intel
        self.const = const
        self.nivel = nivel

    def dar_soco(self, oponente):
        if self.vida <= 0:
            print(f"{self.nome} não pode atacar, FEZ o L!!!")
        dano = self.forca
        oponente.vida -= dano
        print(f"{self.nome} deu um soco em {oponente.nome}")
    def chute
    def intimidar